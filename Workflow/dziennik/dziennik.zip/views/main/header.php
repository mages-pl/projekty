<!doctype html>
<html lang="pl">
<head>
	<meta charset="utf-8">
	<title>iDziennik</title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.4.2/css/all.css">
	<link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Roboto">
	<link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Roboto+Condensed">
	<style>body{font-family:"Roboto", sans-serif;font-size:15px;}h1,h2,h3,h4,h5,h6,th,label{font-family: "Roboto Condensed", sans-serif;}h1:after,h2:after,h3:after,h4:after,h5:after,h6:after{display:block;content:"";background-color:var(--teal);height:3px;width:calc(100% + 40px);margin-top: 10px;}.form-control{font-size:14px;}</style>
	<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
	<!-- dzięki Popper.js działają tooltipy -->
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
	<script>$(function () {$('[data-toggle="tooltip"]').tooltip();})</script>
</head>
<body style="user-select: none;">