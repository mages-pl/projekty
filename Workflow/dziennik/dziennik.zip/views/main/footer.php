	<div style="height:65px;width:100%;"></div>
	<footer class="bg-secondary text-white mt-4 pt-3" style="position: fixed; bottom: 0; width: 100%;">
		<div class="container">
			<div class="row">
				<div class="col-sm-12 col-md-3">
				</div>
				<div class="col-sm-12 col-md-6 text-center">
					<p>(C) <?php echo date('Y');?></p>
				</div>
				<div class="col-sm-12 col-md-3">
					<p class="text-right small">Data: <?php echo date('d.m.Y');?></p>
				</div>
			</div>
		</div>
	</footer>
</body>
</html>